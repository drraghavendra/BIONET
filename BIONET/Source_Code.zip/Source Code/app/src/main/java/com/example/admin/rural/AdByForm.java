package com.example.admin.rural;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Map;

public class AdByForm extends AppCompatActivity {
    public String dt;
    private TextView t1;
    public String foin="";
    public int adus;
    private TextView crpnme;
    private TextView amtmin;
    private TextView dura;
    private TextView dura2;
    private TextView rskg;
    private TextView tot;
    private TextView addr;
    private FirebaseAuth auth2;
    public String rskgval;
    private String amtminval;

    protected void onCreate(Bundle savedInstanceState) {
        dt = getIntent().getStringExtra("dt");
        adus = getIntent().getIntExtra("adus", 1);
        if (adus == 1) {
            setTheme(R.style.admin);
            setTitle(R.string.endbd);
        } else if (adus == 2) {
            setTheme(R.style.buy);
            setTitle(R.string.bdfrm);
        }
        super.onCreate(savedInstanceState);
        //    getLayoutInflater().inflate(R.layout.activity_bidform, frameLayout);

        setContentView(R.layout.activity_adbyform);

        // toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar2);
        if (adus == 1) {
            toolbar.setTitle(R.string.endbd);
        } else if (adus == 2) {
            toolbar.setTitle(R.string.bdfrm);
        }
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdByForm.this, AdminBuyerList.class);
                intent.putExtra("adus", adus);
                startActivity(intent);
                finish();
            }
        });
     //   setSupportActionBar(toolbar);

        // add back arrow to toolbar
       // if (getSupportActionBar() != null) {
         //   getSupportActionBar().setDisplayHomeAsUpEnabled(true);
           // getSupportActionBar().setDisplayShowHomeEnabled(true);
        //}
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("/bidFormData/"+dt);
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String dateString = formatter.format(Long.parseLong(dt));
        String dateString2 = formatter.format(Long.parseLong(dt)+259200000);
        crpnme = findViewById(R.id.con1_5);
        amtmin= findViewById(R.id.con2_5);
        dura=findViewById(R.id.con5_5);
        dura2=findViewById(R.id.con55_5);
        tot=findViewById(R.id.con7_5);
        String datet = "11:00 AM \n" + dateString;
        dura.setText(datet);
        String datet2 = "4:00 PM \n" + dateString2;
        dura2.setText(datet2);
        rskg= findViewById(R.id.con6_5);
        addr= findViewById(R.id.con11_5);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                if (snapshot.exists()) {
                    Map singleUser = (Map) snapshot.getValue();
                    crpnme.setText(singleUser.get("name").toString());
                    amtmin.setText(singleUser.get("amtmin").toString());
                    rskg.setText(singleUser.get("rskg").toString()+" Rs/kg");
                    rskgval = singleUser.get("rskg").toString();
                    amtminval = singleUser.get("amtmin").toString();
                    addr.setText(singleUser.get("address").toString());
                    tot.setText(String.valueOf(Float.parseFloat(rskgval) * Float.parseFloat(amtminval) * 1000));

                    if (snapshot.exists()) {
                        if (adus == 1) {
                            adminPart(dt, snapshot);
                        } else if (adus == 2) {
                            buyerPart(dt, snapshot);
                        }
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(AdByForm.this, AdminBuyerList.class);
        intent.putExtra("adus", adus);
        startActivity(intent);
        finish();
    }

    private void buyerPart(final String dt, final DataSnapshot snapshot) {
        Button butEnd=findViewById(R.id.butnEnd);
        butEnd.setVisibility(View.GONE);
        final Button but=findViewById(R.id.butn);
        but.setActivated(false);
        but.setAlpha((float) 0.1);
        but.setText(R.string.cmpltfrm);
        final EditText fo = findViewById(R.id.amt3);
        auth2 = FirebaseAuth.getInstance();
        String emai = auth2.getCurrentUser().getEmail();
        final String email = emai.replace("@rural.com", "");
        fo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                foin = charSequence.toString();
                chekbtn(but);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chekbtn(but);
                if (but.isActivated()) {
                    new AlertDialog.Builder(AdByForm.this)
                            .setTitle(R.string.rus)
                            .setMessage(getString(R.string.oksb)+"\n"+getString(R.string.crcst)+ Float.parseFloat(foin)*Float.parseFloat(amtminval)*1000)
                            .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {

                                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference myRef2 = database.getReference("/bidFormData/" + dt);
                    DatabaseReference newRf = myRef2.child("rskg");
                    DatabaseReference li = myRef2.child("bidmaxuser");
                    newRf.setValue(foin);
                    li.setValue(email);
                                    Intent intent = new Intent(AdByForm.this, AdminBuyerList.class);
                                    intent.putExtra("adus", adus);
                                    startActivity(intent);
                                    finish();
                                }
                            })
                            .create()
                            .show();
                }
            }
        });
    }

    private void chekbtn(Button butn) {
        if(!foin.equals("")){
            if(Float.parseFloat(foin)<=Float.parseFloat(rskgval)){
                butn.setActivated(false);
                butn.setAlpha((float) 0.1);
                butn.setText(R.string.entrval);
            }
            else {
                butn.setActivated(true);
                butn.setAlpha(1);
                butn.setText(R.string.submit);
            }
        }
        else{
            butn.setActivated(false);
            butn.setAlpha((float) 0.1);
            butn.setText(R.string.cmpltfrm);
        }

    }

    private void adminPart(final String dt,final DataSnapshot snapshot) {
        findViewById(R.id.con45).setVisibility(View.GONE);
        findViewById(R.id.con45_5).setVisibility(View.GONE);
        Button but=findViewById(R.id.butn);
        but.setVisibility(View.GONE);
        Button butend=findViewById(R.id.butnEnd);
        butend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(AdByForm.this)
                        .setTitle(R.string.rus)
                        .setMessage(getString(R.string.oksb))
                        .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                FirebaseDatabase database = FirebaseDatabase.getInstance();
                                DatabaseReference myRef = database.getReference("/bidFormDataLog/"+dt);
                                myRef.setValue(snapshot.getValue());
                                DatabaseReference myRef2 = database.getReference("/bidFormData/"+dt);
                                myRef2.removeValue();
                                Intent intent = new Intent(AdByForm.this, AdminBuyerList.class);
                                intent.putExtra("adus", adus);
                                startActivity(intent);
                                finish();
                            }
                        })
                        .create()
                        .show();


            }
        });
    }
}
