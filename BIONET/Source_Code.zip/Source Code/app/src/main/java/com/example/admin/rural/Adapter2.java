package com.example.admin.rural;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Adapter2 extends RecyclerView.Adapter<Adapter2.PatientViewHolder> {
    private static List<RetItem> _retData;
    private form mContext;
    private String mItems;
    public String k;

    public Adapter2(form context, String items) {
        this.mContext = context;
        this.mItems = items;
        k=LocaleHelper.getLanguage(mContext);
        _retData = new ArrayList<RetItem>(Integer.parseInt(mItems));
        for (int i =0;i<Integer.parseInt(mItems);++i){ _retData.add(new RetItem()); }
    }
    public static List<RetItem> retrieveData()
    {
        return _retData;
    }
    @Override
    public PatientViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.form_row, parent, false);
        return new PatientViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(PatientViewHolder holder, final int position) {
        List<Integer> in = new ArrayList<Integer>();
        for (int i=0; i<Integer.parseInt(mItems); i++) {
            in.add(i+1);
        }
        String ind = in.get(position).toString();
        holder.con.setText(holder.itemView.getContext().getString(R.string.crop_name)+" " + ind);
       // _retData.get(position).name = holder.name.getSelectedItem().toString();
        newlist(holder.name);
        holder.name.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int
                    i, long id) {
                // On selecting a spinner item
                String kk=parent.getSelectedItem().toString();
                String kk2=chktran2(kk);
                _retData.get(position).name = kk2;

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // todo for nothing selected
            }
        });
        holder.amt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                _retData.get(position).amt = Integer.parseInt(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }
    private void newlist(final Spinner spin) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("/biddingMax");
        myRef.orderByKey().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Map<String, Object> mItems= (Map<String, Object>) snapshot.getValue();
                    List<String> list = new ArrayList<String>();
                    for (Map.Entry<String, Object> entry : mItems.entrySet()) {
                        String s = new String();
                        //   Map singleUser = (Map) entry.getValue();
                        //   Map<String, Object> kk = (Map<String, Object>) entry.getValue();
                        String ll= chktran(entry.getKey());
                        list.add(ll);

                    }
                    ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(mContext, android.R.layout.simple_spinner_item, list);
                    spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin.setAdapter(spinnerAdapter);


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    private String chktran2(String dt) {
        String dt2;
        dt2=dt.replace("बाजरा","Bajra").replace("चना","Gram").replace("ज्वार","Jawar").replace("मसूर","Lentil").replace("मक्का","Maize").replace("सरसों","Mustard").replace("सोयाबीन","Soya bean").replace("गन्ना","Sugarcane").replace("गेहूँ","Wheat").replace("मूंगफली","Groundnut").replace("चावल","Rice").replace("बाजरी","Bajra").replace("ग्राम","Gram").replace("जवार","Jawar").replace("दालचिनी","Lentil").replace("मका","Maize").replace("मोहरी","Mustard").replace("सोयाबीन","Soya bean").replace("ऊस","Sugarcane").replace("गहू","Wheat").replace("भुईमूग","Groundnut").replace("तांदूळ","Rice");
        return dt2;
    }
    private String chktran(String dt) {
        String dt2=dt;
        if(k.equals("hi")){
            if(dt.contains("Bajra")){
                dt2=dt.replace("Bajra","बाजरा");
            }
            else if(dt.contains("Gram")){
                dt2=dt.replace("Gram","चना");
            }
            else if(dt.contains("Jawar")){
                dt2=dt.replace("Jawar","ज्वार");
            }
            else if(dt.contains("Lentil")){
                dt2=dt.replace("Lentil","मसूर");
            }
            else if(dt.contains("Maize")){
                dt2=dt.replace("Maize","मक्का");
            }
            else if(dt.contains("Mustard")){
                dt2=dt.replace("Mustard","सरसों");
            }
            else if(dt.contains("Soya bean")){
                dt2=dt.replace("Soya bean","सोयाबीन");
            }
            else if(dt.contains("Sugarcane")){
                dt2=dt.replace("Sugarcane","गन्ना");
            }
            else if(dt.contains("Wheat")){
                dt2=dt.replace("Wheat","गेहूँ");
            }
            else if(dt.contains("Groundnut")){
                dt2=dt.replace("Groundnut","मूंगफली");
            }
            else if(dt.contains("Rice")){
                dt2=dt.replace("Rice","चावल");
            }
        }
        else if(k.equals("mr")){
            if(dt.contains("Bajra")){
                dt2=dt.replace("Bajra","बाजरी");
            }
            else if(dt.contains("Gram")){
                dt2=dt.replace("Gram","ग्राम");
            }
            else if(dt.contains("Jawar")){
                dt2=dt.replace("Jawar","जवार");
            }
            else if(dt.contains("Lentil")){
                dt2=dt.replace("Lentil","दालचिनी");
            }
            else if(dt.contains("Maize")){
                dt2=dt.replace("Maize","मका");
            }
            else if(dt.contains("Mustard")){
                dt2=dt.replace("Mustard","मोहरी");
            }
            else if(dt.contains("Soya bean")){
                dt2=dt.replace("Soya bean","सोयाबीन");
            }
            else if(dt.contains("Sugarcane")){
                dt2=dt.replace("Sugarcane","ऊस");
            }
            else if(dt.contains("Wheat")){
                dt2=dt.replace("Wheat","गहू");
            }
            else if(dt.contains("Groundnut")){
                dt2=dt.replace("Groundnut","भुईमूग");
            }
            else if(dt.contains("Rice")){
                dt2=dt.replace("Rice","तांदूळ");
            }
        }
        else if(k.equals("en")){
            dt2= dt;
        }
        return dt2;
    }

    private Context getContext() {
        return mContext;
    }

    @Override
    public int getItemCount() {
        return Integer.parseInt(mItems) ;
    }

    class PatientViewHolder extends RecyclerView.ViewHolder{
        private TextView con;
        private Spinner name;
        private EditText amt;
        private Spinner unit;
        public PatientViewHolder(View itemView) {
            super(itemView);
            con = itemView.findViewById(R.id.con);
            name= itemView.findViewById(R.id.spin);
            amt= itemView.findViewById(R.id.amt);



        }


    }

}