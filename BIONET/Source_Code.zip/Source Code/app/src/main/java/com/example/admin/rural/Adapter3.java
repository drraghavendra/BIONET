package com.example.admin.rural;

import android.graphics.Bitmap;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.ui.IconGenerator;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class Adapter3 extends RecyclerView.Adapter<Adapter3.PatientViewHolder> {
    private static List<RetItem> _retData;
    private AdminUserList mContext;
    private Map<String, Object> mItems;
    ArrayList<String> email = new ArrayList<>();
    ArrayList<String> sd = new ArrayList<>();

    public Adapter3(AdminUserList context, Map<String, Object> items) {
        this.mContext = context;
        this.mItems = items;
        for (Map.Entry<String, Object> entry : mItems.entrySet()) {
            String s=new String();
            //Get user map
            Map singleUser = (Map) entry.getValue();
            Map<String, Object> kk = (Map<String, Object>) entry.getValue();

            //Get phone field and append to list

            for (Map.Entry<String, Object> entry2 : kk.entrySet()) {
                if (entry2.getValue() instanceof ArrayList) {
                    ArrayList kk2 = (ArrayList) entry2.getValue();
                    for (Object entry3 : kk2) {
                        //       amt.add((String) entry3.getValue().get("amt"));
                        //        name.add((String) entry3.get("name"));
                        s = s+entry3.toString();
                    }

                }
                // rel= (RetItem) singleUser2.entrySet();
            }
            sd.add(s);
            email.add((String) singleUser.get("email"));
        }

    }
    @Override
    public PatientViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.form_row4, parent, false);
        return new PatientViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(PatientViewHolder holder, final int position) {

      // Map<String, Object> k= (Map<String, Object>) mItems.values() .get(position);

        String uid=email.get(position).replace("@rural.com", "");
        String dt=sd.get(position).replace("name=", "").replace("amt=", "").replace("}{", "}\n").replace("{","").replace("}"," Kg").replace(",","");
        holder.phn.setText(uid);
        holder.dta.setText(dt);

    }


    @Override
    public int getItemCount() {
       return mItems.size();
        // return Integer.parseInt(mItems) ;
    }

    class PatientViewHolder extends RecyclerView.ViewHolder{
        private TextView phn;
        private TextView dta;
        private EditText amt;
        private Spinner unit;
        public PatientViewHolder(View itemView) {
            super(itemView);
            phn = itemView.findViewById(R.id.con1_5);
            dta= itemView.findViewById(R.id.con2_5);




        }


    }

}