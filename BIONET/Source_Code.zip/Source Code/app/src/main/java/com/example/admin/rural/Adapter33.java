package com.example.admin.rural;

import android.os.Handler;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;


import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Adapter33 extends RecyclerView.Adapter<Adapter33.PatientViewHolder> {
    private static List<RetItem> _retData;
    private AdminSellerLog mContext;
    private Map<String, Object> mItems;
    public String k;
    ArrayList<String> email = new ArrayList<>();
    ArrayList<String> sd = new ArrayList<>();
    ArrayList<ArrayList> ssss= new ArrayList<>();
    ArrayList<String> name = new ArrayList<>();
    ArrayList<String> amt = new ArrayList<>();
int adus;
    public Adapter33(AdminSellerLog context, Map<String, Object> items, int adus) {
        this.mContext = context;
        this.mItems = items;
        this.adus=adus;
        k=LocaleHelper.getLanguage(mContext);
        for (Map.Entry<String, Object> entry : mItems.entrySet()) {
            String s = new String();
            //Get user map
            Map singleUser = (Map) entry.getValue();
            Map<String, Object> kk = (Map<String, Object>) entry.getValue();
            //Get phone field and append to list

                for (Map.Entry<String, Object> entry2 : kk.entrySet()) {
                    if (entry2.getValue() instanceof ArrayList) {
                        ArrayList kk2 = (ArrayList) entry2.getValue();
                        for (Object entry3 : kk2) {
                            //       amt.add((String) entry3.getValue().get("amt"));
                            //        name.add((String) entry3.get("name"));
                            s = s + entry3.toString();
                        }

                    }
                    // rel= (RetItem) singleUser2.entrySet();

                }
                sd.add(s);
                email.add((String) singleUser.get("email"));
        }
    }
    @Override
    public PatientViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.form_row4, parent, false);
        return new PatientViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final PatientViewHolder holder, final int position) {

        // Map<String, Object> k= (Map<String, Object>) mItems.values() .get(position);
        String uid=email.get(position).replace("@rural.com", "");
        FirebaseAuth auth2 = FirebaseAuth.getInstance();
        String emai = auth2.getCurrentUser().getEmail();
        String email = emai.replace("@rural.com", "");
        if (adus==0) {
            if (!uid.equals("None")) {
                if (!uid.equals(email)) {
                    holder.dat4.setVisibility(View.GONE);
                    holder.itemView.setVisibility(View.GONE);
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        public void run() {
                            int position2=holder.getAdapterPosition();
                            mItems.remove(position2);
                            notifyItemRemoved(position2);
                            notifyItemRangeChanged(position2, mItems.size());}
                    }, 200);   //5 seconds
                }
                else {
                    holder.dat4.setVisibility(View.VISIBLE);
                    holder.itemView.setVisibility(View.VISIBLE);
                    String dt=sd.get(position).replace("name=", "").replace("amt=", "").replace("}{", "}\n").replace("{","").replace("}"," "+mContext.getString(R.string.kg)).replace(",","");
                    String ll= chktran(holder,dt);
                    holder.phn.setText(uid);
                    holder.dta.setText(ll);
                }
            }
        }
        else{
            String dt=sd.get(position).replace("name=", "").replace("amt=", "").replace("}{", "}\n").replace("{","").replace("}"," "+mContext.getString(R.string.kg)).replace(",","");
            String ll= chktran(holder,dt);
            holder.phn.setText(uid);
            holder.dta.setText(ll);
        }
    }

    private String chktran(PatientViewHolder holder, String dt) {
        String dt2=dt;
        if(k.equals("hi")){
            if(dt.contains("Bajra")){
                dt2=dt.replace("Bajra","बाजरा");
            }
            else if(dt.contains("Gram")){
                dt2=dt.replace("Gram","चना");
            }
            else if(dt.contains("Jawar")){
                dt2=dt.replace("Jawar","ज्वार");
            }
            else if(dt.contains("Lentil")){
                dt2=dt.replace("Lentil","मसूर");
            }
            else if(dt.contains("Maize")){
                dt2=dt.replace("Maize","मक्का");
            }
            else if(dt.contains("Mustard")){
                dt2=dt.replace("Mustard","सरसों");
            }
            else if(dt.contains("Soya bean")){
                dt2=dt.replace("Soya bean","सोयाबीन");
            }
            else if(dt.contains("Sugarcane")){
                dt2=dt.replace("Sugarcane","गन्ना");
            }
            else if(dt.contains("Wheat")){
                dt2=dt.replace("Wheat","गेहूँ");
            }
            else if(dt.contains("Groundnut")){
                dt2=dt.replace("Groundnut","मूंगफली");
            }
            else if(dt.contains("Rice")){
                dt2=dt.replace("Rice","चावल");
            }
        }
        else if(k.equals("mr")){
            if(dt.contains("Bajra")){
                dt2=dt.replace("Bajra","बाजरी");
            }
            else if(dt.contains("Gram")){
                dt2=dt.replace("Gram","ग्राम");
            }
            else if(dt.contains("Jawar")){
                dt2=dt.replace("Jawar","जवार");
            }
            else if(dt.contains("Lentil")){
                dt2=dt.replace("Lentil","दालचिनी");
            }
            else if(dt.contains("Maize")){
                dt2=dt.replace("Maize","मका");
            }
            else if(dt.contains("Mustard")){
                dt2=dt.replace("Mustard","मोहरी");
            }
            else if(dt.contains("Soya bean")){
                dt2=dt.replace("Soya bean","सोयाबीन");
            }
            else if(dt.contains("Sugarcane")){
                dt2=dt.replace("Sugarcane","ऊस");
            }
            else if(dt.contains("Wheat")){
                dt2=dt.replace("Wheat","गहू");
            }
            else if(dt.contains("Groundnut")){
                dt2=dt.replace("Groundnut","भुईमूग");
            }
            else if(dt.contains("Rice")){
                dt2=dt.replace("Rice","तांदूळ");
            }
        }
        else if(k.equals("en")){
            dt2= dt;
        }
        return dt2;
    }


    @Override
    public int getItemCount() {
        return mItems.size();

        // return Integer.parseInt(mItems) ;
    }

    class PatientViewHolder extends RecyclerView.ViewHolder{
        private TextView phn;
        private TextView dta;
        private EditText amt;
        private LinearLayout dat4;
        private Spinner unit;
        public PatientViewHolder(View itemView) {
            super(itemView);
            phn = itemView.findViewById(R.id.con1_5);
            dta= itemView.findViewById(R.id.con2_5);
            dat4=itemView.findViewById(R.id.dat4);




        }


    }

}