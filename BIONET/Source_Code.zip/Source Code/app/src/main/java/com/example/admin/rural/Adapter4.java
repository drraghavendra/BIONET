package com.example.admin.rural;

import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Adapter4 extends RecyclerView.Adapter<Adapter4.PatientViewHolder> {
    public static List<RetItem2> _retData;
    private BuyActivity mContext;
    private String mItems;

    public Adapter4(BuyActivity context, String items) {
        this.mContext = context;
        this.mItems = items;
        _retData = new ArrayList<RetItem2>(Integer.parseInt(mItems));
        for (int i =0;i<Integer.parseInt(mItems);++i){ _retData.add(new RetItem2()); }
    }
    public static List<RetItem2> retrieveData()
    {
        return _retData;
    }
    @Override
    public PatientViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.form_row3, parent, false);
        return new PatientViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(PatientViewHolder holder, final int position) {
        List<Integer> in = new ArrayList<Integer>();
        for (int i=0; i<Integer.parseInt(mItems); i++) {
            in.add(i+1);
        }
        String ind= in.get(position).toString();
        holder.con.setText(holder.itemView.getContext().getString(R.string.crop_name)+" "+ind);
        //_retData.get(position).name = holder.name.getSelectedItem().toString();
        holder.name.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int
                    i, long id) {
                // On selecting a spinner item
                _retData.get(position).name = parent.getSelectedItem().toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // todo for nothing selected
            }
        });

        holder.amt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                _retData.get(position).tamt = Integer.parseInt(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        holder.unit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                _retData.get(position).tprice = Integer.parseInt(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }


    @Override
    public int getItemCount() {
        return Integer.parseInt(mItems) ;
    }

    class PatientViewHolder extends RecyclerView.ViewHolder{
        private TextView con;
        private Spinner name;
        private EditText amt;
        private EditText unit;
        public PatientViewHolder(View itemView) {
            super(itemView);
            con = itemView.findViewById(R.id.con);
            name= itemView.findViewById(R.id.spin);
            amt= itemView.findViewById(R.id.amt);
            unit = itemView.findViewById(R.id.spin2);



        }


    }

}