package com.example.admin.rural;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class Adapter6 extends RecyclerView.Adapter<Adapter6.PatientViewHolder> {
    private static List<RetItem> _retData;
    ArrayList<String>  dt=new ArrayList<>();
    private AdminBuyerListLog mContext;
    public int adus;
    private Map<String, Object> mItems;
    ArrayList<String> crpname = new ArrayList<>();
    ArrayList<String> amtmin = new ArrayList<>();
    ArrayList<String> rskg = new ArrayList<>();
    ArrayList<String> minrskg = new ArrayList<>();
    ArrayList<String> dura = new ArrayList<>();
    ArrayList<String> dura2 = new ArrayList<>();
    ArrayList<String> addr = new ArrayList<>();
    ArrayList<String> bidwin = new ArrayList<>();
    ArrayList<String> bidwin3 = new ArrayList<>();

    public Adapter6(AdminBuyerListLog context, Map<String, Object> items, int adus) {
        this.adus=adus;
        this.mContext = context;
        this.mItems = items;
        for (Map.Entry<String, Object> entry : mItems.entrySet()) {
            String s=new String();
            //Get user map
            Map singleUser = (Map) entry.getValue();
            Map<String, Object> kk = (Map<String, Object>) entry.getValue();
            //Get phone field and append to list
     /*       for (Map.Entry<String, Object> entry2 : kk.entrySet()) {
                if (entry2.getValue() instanceof ArrayList) {
                    ArrayList kk2 = (ArrayList) entry2.getValue();
                    for (Object entry3 : kk2) {
                        //       amt.add((String) entry3.getValue().get("amt"));
                        //        name.add((String) entry3.get("name"));
                        s = s + entry3.toString();
                    }
                }
                // rel= (RetItem) singleUser2.entrySet();
            }*/
            // sd.add(s);
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
            dt.add(entry.getKey());
            String dateString = formatter.format(Long.parseLong(entry.getKey()));
            String dateString2 = formatter.format(Long.parseLong(entry.getKey())+259200000);
            crpname.add((String) singleUser.get("name"));
            amtmin.add((String) singleUser.get("amtmin"));
            addr.add((String) singleUser.get("address"));
            rskg.add((String) singleUser.get("rskg"));
            minrskg.add((String) singleUser.get("minrskg"));
            dura.add((String) "11:00 AM \n"+dateString);
            dura2.add((String) "4:00 PM \n"+dateString2);
            bidwin.add((String) singleUser.get("bidmaxuser"));
        }
    }
    @NonNull
    @Override
    public PatientViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.form_row2, parent, false);
        return new PatientViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull PatientViewHolder holder, final int position) {
        // Map<String, Object> k= (Map<String, Object>) mItems.values() .get(position);
        //  String dt=sd.get(position).replace("tprice=", "Price in Rs/Kg ").replace("name=", "Name ").replace("tamt=", "Amount in Kg ").replace("}{", "}\n{");
        String uid=crpname.get(position);
        holder.crpnme.setText(uid);
        String uid22=addr.get(position);
        holder.addr.setText(uid22);
        String uid2=amtmin.get(position);
        holder.amtmin.setText(uid2);
        String uid4=rskg.get(position);
        holder.rskg.setText(uid4);
        String uid5=dura.get(position);
        holder.dura.setText(uid5);
        String uid55=dura2.get(position);
        holder.dura2.setText(uid55);
        holder.bidwintext.setText(R.string.fnlwnr);
        holder.rskgtext.setText(R.string.fina);
        holder.tot.setText(String.valueOf(Float.parseFloat(uid4)*Float.parseFloat(uid2)*1000));
        adminBuyerDivider(holder,position);
        //holder.dta.setText(dt);
    }

    private void adminBuyerDivider(PatientViewHolder holder,int position) {
        String uid6=bidwin.get(position);
        if(adus==1){
            String uid44=minrskg.get(position);
            holder.minrskg.setText(uid44);
            if (uid6.equals("None")) {
                holder.bidwintext.setVisibility(View.GONE);
                holder.bidwin.setVisibility(View.GONE);
            }
            else
            {
                holder.bidwin.setText(uid6);
            }

        }
        else if(adus==2){
            FirebaseAuth auth2 = FirebaseAuth.getInstance();
            String emai = auth2.getCurrentUser().getEmail();
            String uid44=minrskg.get(position);
            holder.minrskg.setVisibility(View.GONE);
            holder.minrskgtext.setVisibility(View.GONE);
            String email = emai.replace("@rural.com", "");
            holder.bidwintext.setVisibility(View.GONE);
            holder.bidwin.setVisibility(View.GONE);
            if (!uid6.equals("None")) {
                if (uid6.equals(email)) {
                    holder.bidwintext.setVisibility(View.VISIBLE);
                    holder.bidwin.setVisibility(View.VISIBLE);
                    holder.bidwin.setText(R.string.you);
                }
                else{
                    holder.dat2.setVisibility(View.GONE);
                    notifyDataSetChanged();
                    holder.bidwintext.setVisibility(View.GONE);
                    holder.bidwin.setVisibility(View.GONE);
                }

            }
            else
            {   holder.bidwintext.setVisibility(View.GONE);
                holder.bidwin.setVisibility(View.GONE);

            }
        }
    }

    @Override
    public int getItemCount() {
        return mItems.size();
        // return Integer.parseInt(mItems) ;
    }

    class PatientViewHolder extends RecyclerView.ViewHolder{
        private RelativeLayout dat;
        private ConstraintLayout dat2;
        private TextView crpnme;
        private TextView amtmin;
        private TextView rskg;
        private TextView rskgtext;
        private TextView dura;
        private TextView dura2;
        private TextView minrskg;
        private LinearLayout minrskgtext;
        private TextView  bidwin;
        private TextView  bidwintext;
        private TextView  bidwin4;
        private TextView  tot;
        private TextView  addr;
        private TextView  bidwintext4;
        public PatientViewHolder(View itemView) {
            super(itemView);
            dat = itemView.findViewById(R.id.dat);
            dat2 = itemView.findViewById(R.id.dat2);
            addr=itemView.findViewById(R.id.con22_5);
            crpnme = itemView.findViewById(R.id.con1_5);
            amtmin= itemView.findViewById(R.id.con2_5);
            minrskg= itemView.findViewById(R.id.con4_5);
            rskg= itemView.findViewById(R.id.con44_5);
            minrskgtext= itemView.findViewById(R.id.l4);
            rskgtext= itemView.findViewById(R.id.con44);
            tot= itemView.findViewById(R.id.con444_5);
            dura = itemView.findViewById(R.id.con5_5);
            dura2 = itemView.findViewById(R.id.con55_5);
            bidwin= itemView.findViewById(R.id.con6_5);
            bidwintext= itemView.findViewById(R.id.con6);
        }
    }

}