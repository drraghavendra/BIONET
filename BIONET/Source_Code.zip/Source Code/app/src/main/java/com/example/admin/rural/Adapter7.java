package com.example.admin.rural;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Adapter7 extends RecyclerView.Adapter<Adapter7.PatientViewHolder> {
    private static List<RetItem> _retData;
    ArrayList<String> dt = new ArrayList<>();
    private AdminUserPriceList mContext;
    public int adus;
    public String k;
    private Map<String, Object> mItems;
    ArrayList<String> crpname = new ArrayList<>();
    ArrayList<String> rskg = new ArrayList<>();


    public Adapter7(AdminUserPriceList context, Map<String, Object> items, int adus) {
        this.adus = adus;
        this.mContext = context;
        this.mItems = items;
        k=LocaleHelper.getLanguage(mContext);
        for (Map.Entry<String, Object> entry : mItems.entrySet()) {
            String s = new String();
         //   Map singleUser = (Map) entry.getValue();
         //   Map<String, Object> kk = (Map<String, Object>) entry.getValue();
            crpname.add((String) entry.getKey());
            rskg.add((String) entry.getValue());

        }
    }

    @NonNull
    @Override
    public PatientViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.form_rowprice, parent, false);
        return new PatientViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull PatientViewHolder holder, final int position) {
        // Map<String, Object> k= (Map<String, Object>) mItems.values() .get(position);
        //  String dt=sd.get(position).replace("tprice=", "Price in Rs/Kg ").replace("name=", "Name ").replace("tamt=", "Amount in Kg ").replace("}{", "}\n{");
        String uid = crpname.get(position);
        String ll= chktran(holder,uid);
        holder.crpnme.setText(ll);
        String uid4 = rskg.get(position);

        holder.rskg.setText(uid4+" "+holder.itemView.getContext().getString(R.string.rs_kg));
       //holder.dta.setText(dt);
        if (adus==1){
                holder.dat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, formPrice.class);
                intent.putExtra("dt", crpname.get(position));
                intent.putExtra("dt2", rskg.get(position));
                intent.putExtra("adus", 0);
                v.getContext().startActivity(intent);
            }
        });}
    }
    private String chktran(PatientViewHolder holder, String dt) {
        String dt2=dt;
        if(k.equals("hi")){
            if(dt.contains("Bajra")){
                dt2=dt.replace("Bajra","बाजरा");
            }
            else if(dt.contains("Gram")){
                dt2=dt.replace("Gram","चना");
            }
            else if(dt.contains("Jawar")){
                dt2=dt.replace("Jawar","ज्वार");
            }
            else if(dt.contains("Lentil")){
                dt2=dt.replace("Lentil","मसूर");
            }
            else if(dt.contains("Maize")){
                dt2=dt.replace("Maize","मक्का");
            }
            else if(dt.contains("Mustard")){
                dt2=dt.replace("Mustard","सरसों");
            }
            else if(dt.contains("Soya bean")){
                dt2=dt.replace("Soya bean","सोयाबीन");
            }
            else if(dt.contains("Sugarcane")){
                dt2=dt.replace("Sugarcane","गन्ना");
            }
            else if(dt.contains("Wheat")){
                dt2=dt.replace("Wheat","गेहूँ");
            }
            else if(dt.contains("Groundnut")){
                dt2=dt.replace("Groundnut","मूंगफली");
            }
            else if(dt.contains("Rice")){
                dt2=dt.replace("Rice","चावल");
            }
        }
        else if(k.equals("mr")){
            if(dt.contains("Bajra")){
                dt2=dt.replace("Bajra","बाजरी");
            }
            else if(dt.contains("Gram")){
                dt2=dt.replace("Gram","ग्राम");
            }
            else if(dt.contains("Jawar")){
                dt2=dt.replace("Jawar","जवार");
            }
            else if(dt.contains("Lentil")){
                dt2=dt.replace("Lentil","दालचिनी");
            }
            else if(dt.contains("Maize")){
                dt2=dt.replace("Maize","मका");
            }
            else if(dt.contains("Mustard")){
                dt2=dt.replace("Mustard","मोहरी");
            }
            else if(dt.contains("Soya bean")){
                dt2=dt.replace("Soya bean","सोयाबीन");
            }
            else if(dt.contains("Sugarcane")){
                dt2=dt.replace("Sugarcane","ऊस");
            }
            else if(dt.contains("Wheat")){
                dt2=dt.replace("Wheat","गहू");
            }
            else if(dt.contains("Groundnut")){
                dt2=dt.replace("Groundnut","भुईमूग");
            }
            else if(dt.contains("Rice")){
                dt2=dt.replace("Rice","तांदूळ");
            }
        }

        else if(k.equals("en")){
            dt2= dt;
        }
        return dt2;
    }


    @Override
    public int getItemCount() {
        return mItems.size();
        // return Integer.parseInt(mItems) ;
    }

    class PatientViewHolder extends RecyclerView.ViewHolder {
        private RelativeLayout dat;
        private ConstraintLayout dat2;
        private TextView crpnme;
        private TextView rskg;

        public PatientViewHolder(View itemView) {
            super(itemView);
            dat = itemView.findViewById(R.id.dat);
            dat2 = itemView.findViewById(R.id.dat2);
            crpnme = itemView.findViewById(R.id.con1_5);
            rskg = itemView.findViewById(R.id.con4_5);
        }
    }
}

