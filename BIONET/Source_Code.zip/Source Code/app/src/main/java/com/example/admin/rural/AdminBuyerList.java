package com.example.admin.rural;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class AdminBuyerList extends MenuActivity {
    private RecyclerView mPatientRecyclerView;
    public int adus;

    protected void onCreate(Bundle savedInstanceState) {
        adus = getIntent().getIntExtra("adus", 1);
        if (adus == 1) {
            setTheme(R.style.admin);
        } else if (adus == 2) {
            setTheme(R.style.buy);
        }
        super.onCreate(savedInstanceState);
        getLayoutInflater().inflate(R.layout.activity_adbyl, frameLayout);
        setTitle(getString(R.string.title_buyer_biding_list));
        mPatientRecyclerView = this.findViewById(R.id.patientRecyclerView);
        mPatientRecyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
       // linearLayoutManager.setReverseLayout(true);
       // linearLayoutManager.setStackFromEnd(true);
        mPatientRecyclerView.setLayoutManager(linearLayoutManager);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("/bidFormData/");
        FloatingActionButton fab = findViewById(R.id.fab);
        if (adus == 1) {
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(AdminBuyerList.this, formBid.class);
                    intent.putExtra("adus", adus);
                    getApplication().setTheme(R.style.admin);
                    startActivity(intent);
                    finish();
                }
            });

        } else if (adus == 2) {
            fab.setVisibility(View.GONE);
        }
        myRef.orderByKey().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                if (snapshot.exists()) {
                    updateAdapter((Map<String, Object>) snapshot.getValue());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public void updateAdapter(Map<String, Object> num) {
        Adapter5 adapter = new Adapter5(this, num, adus);
        adapter.notifyDataSetChanged();
        mPatientRecyclerView.setAdapter(adapter);
    }
}
