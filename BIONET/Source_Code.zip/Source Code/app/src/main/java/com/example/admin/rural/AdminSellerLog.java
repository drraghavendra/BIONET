package com.example.admin.rural;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class AdminSellerLog extends MenuActivity {
    private RecyclerView mPatientRecyclerView;

    protected void onCreate(Bundle savedInstanceState) {
        adus = getIntent().getIntExtra("adus", 1);
        if (adus == 1) {
            setTheme(R.style.admin);
            setTitle(getString(R.string.title_user_selling_log2));
        } else if (adus == 0) {
            setTheme(R.style.user);
            setTitle(getString(R.string.title_user_selling_log));
        }
        super.onCreate(savedInstanceState);
        getLayoutInflater().inflate(R.layout.activity_adusl, frameLayout);

        mPatientRecyclerView = this.findViewById(R.id.patientRecyclerView);
        mPatientRecyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mPatientRecyclerView.setLayoutManager(linearLayoutManager);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("/dataLog/");
if(adus==1) {
    myRef.addValueEventListener(new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot snapshot) {
            // This method is called once with the initial value and again
            // whenever data at this location is updated.
            if (snapshot.exists()) {
                updateAdapter((Map<String, Object>) snapshot.getValue());
            }
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    });
}
        if(adus==0) {
            FirebaseAuth auth2 = FirebaseAuth.getInstance();
            String emai = auth2.getCurrentUser().getEmail();
            String email = emai.replace("@rural.com", "");
            myRef.orderByChild("email").equalTo(email).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    // This method is called once with the initial value and again
                    // whenever data at this location is updated.
                    if (snapshot.exists()) {
                        updateAdapter((Map<String, Object>) snapshot.getValue());
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }

    public void updateAdapter(Map<String, Object> num) {
        Adapter33 adapter = new Adapter33(this,num,adus);
        adapter.notifyDataSetChanged();
        mPatientRecyclerView.setAdapter(adapter);
    }

}
