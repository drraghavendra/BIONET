package com.example.admin.rural;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class AdminUserList extends MenuActivity  {
    private RecyclerView mPatientRecyclerView;

    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.admin);
        super.onCreate(savedInstanceState);
        getLayoutInflater().inflate(R.layout.activity_adusl, frameLayout);
        setTitle(getString(R.string.title_user_selling_list));
        mPatientRecyclerView = this.findViewById(R.id.patientRecyclerView);
        mPatientRecyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mPatientRecyclerView.setLayoutManager(linearLayoutManager);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("/data/");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                if (snapshot.exists()) {
                    updateAdapter((Map<String, Object>) snapshot.getValue());
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    public void updateAdapter(Map<String, Object> num) {
        Adapter3 adapter = new Adapter3(this,num);
        adapter.notifyDataSetChanged();
        mPatientRecyclerView.setAdapter(adapter);
    }
}
