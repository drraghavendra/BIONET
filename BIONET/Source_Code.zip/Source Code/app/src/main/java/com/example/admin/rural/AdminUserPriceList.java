package com.example.admin.rural;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class AdminUserPriceList extends MenuActivity{
    private RecyclerView mPatientRecyclerView;
    public int adus;

    protected void onCreate(Bundle savedInstanceState) {
        adus = getIntent().getIntExtra("adus", 1);
        if (adus == 1) {
            setTheme(R.style.admin);
        } else if (adus == 0) {
            setTheme(R.style.user);
        }
        super.onCreate(savedInstanceState);
        getLayoutInflater().inflate(R.layout.activity_aduspricelist, frameLayout);
        setTitle(getString(R.string.title_price_list));
        mPatientRecyclerView = this.findViewById(R.id.patientRecyclerView);
        mPatientRecyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        // linearLayoutManager.setReverseLayout(true);
        // linearLayoutManager.setStackFromEnd(true);
        mPatientRecyclerView.setLayoutManager(linearLayoutManager);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("/biddingMax/");
        FloatingActionButton fab = findViewById(R.id.fab);
        if (adus == 1) {
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(AdminUserPriceList.this, formPrice.class);
                    intent.putExtra("adus",1);
                    getApplication().setTheme(R.style.admin);
                    startActivity(intent);
                    finish();
                }
            });

        } else if (adus == 0) {
            fab.setVisibility(View.GONE);
        }
        myRef.orderByKey().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    updateAdapter((Map<String, Object>) snapshot.getValue());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public void updateAdapter(Map<String, Object> num) {
        Adapter7 adapter = new Adapter7(this, num, adus);
        adapter.notifyDataSetChanged();
        mPatientRecyclerView.setAdapter(adapter);
    }

}
