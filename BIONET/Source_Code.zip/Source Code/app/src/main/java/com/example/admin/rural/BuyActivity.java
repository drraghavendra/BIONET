package com.example.admin.rural;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Spinner;

import com.google.android.gms.location.LocationServices;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class BuyActivity extends MenuActivity {
    private static RecyclerView mPatientRecyclerViewby;
    private FirebaseAuth auth2;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.buy);
        getLayoutInflater().inflate(R.layout.activity_buy, frameLayout);
        setTitle("Buyer Panel");
        mPatientRecyclerViewby = this.findViewById(R.id.patientRecyclerViewby);
        mPatientRecyclerViewby.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mPatientRecyclerViewby.setLayoutManager(linearLayoutManager);
        addListenerOnSpinnerItemSelection2();
    }

    public void updateAdapter(String num) {
        Adapter4 adapter4 = new Adapter4(this, num);
        adapter4.notifyDataSetChanged();
        mPatientRecyclerViewby.setAdapter(adapter4);
    }

    public void addListenerOnSpinnerItemSelection2() {
        Spinner spinner1 = findViewById(R.id.spinnerby);
        spinner1.setOnItemSelectedListener(new CustomOnItemSelectedListener2());
    }

    public void onClickBtnby(View view) {
        List<RetItem2> rel = Adapter4.retrieveData();
        auth2 = FirebaseAuth.getInstance();
        String uid = auth2.getCurrentUser().getUid();
        String emai = auth2.getCurrentUser().getEmail();
        String email = emai.replace("@rural.com", "");
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("/databy/");
        DatabaseReference newRef = myRef.child(uid).child("latest");
        DatabaseReference newRf = myRef.child(uid).child("email");
        newRf.setValue(email);
        newRef.setValue(rel);
        new AlertDialog.Builder(this)
                .setTitle(R.string.suc)
                .setMessage(R.string.submtd)
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Prompt the user once explanation has been shown
                    }
                })
                .create()
                .show();
    }
}
