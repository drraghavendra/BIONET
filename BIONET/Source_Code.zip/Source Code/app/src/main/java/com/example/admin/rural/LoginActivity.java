package com.example.admin.rural;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.media.Image;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Locale;
import java.util.Objects;

public class LoginActivity extends AppCompatActivity {

    private EditText inputEmail, inputPassword;
    private FirebaseAuth auth;
    private ProgressBar progressBar;
    private Button btnSignup, btnLogin, btnReset;
    final String PREFS_NAME = "MyPrefsFile";
    private final String FIRST_TIME_LOGIN = "FIRST_LOGIN";
    private final String LANGUAGE_HINDI_CODE = "hi";
    private final String LANGUAGE_MARATHI_CODE = "mr";
    private final String LANGUAGE_ENGLISH_CODE = "en";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Get Firebase auth instance
        auth = FirebaseAuth.getInstance();

        // set the view now
        setContentView(R.layout.activity_login);
        final SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);

        if (settings.getBoolean(FIRST_TIME_LOGIN, true)) {

            AlertDialog.Builder builderSingle = new AlertDialog.Builder(this);
            builderSingle.setTitle(getString(R.string.select_language));

            final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.select_dialog_singlechoice);
            arrayAdapter.add(getString(R.string.setting_language_english));
            arrayAdapter.add(getString(R.string.setting_language_hindi));
            arrayAdapter.add(getString(R.string.setting_language_marathi));
            builderSingle.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });

            builderSingle.setAdapter(arrayAdapter, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String strName = arrayAdapter.getItem(which);
                    settings.edit().putString(getString(R.string.setting_language), strName).commit();
                    settings.edit().putBoolean(FIRST_TIME_LOGIN, false).commit();
                    if (strName.equals(getString(R.string.setting_language_hindi))) {
                        LocaleHelper.setLocale(getApplicationContext(), LANGUAGE_HINDI_CODE);
                    } else if (strName.equals(getString(R.string.setting_language_marathi))) {
                        LocaleHelper.setLocale(getApplicationContext(), LANGUAGE_MARATHI_CODE);
                    } else {
                        LocaleHelper.setLocale(getApplicationContext(), LANGUAGE_ENGLISH_CODE);
                    }
                    startActivity(new Intent(getApplicationContext(),LoginActivity.class));
                    finish();
                }
            });
            builderSingle.show();
            //the app is being launched for first time, do something
            // first time task
            // record the fact that the app has been started at least once
        }
        inputEmail = findViewById(R.id.email);
        inputPassword = findViewById(R.id.password);
        progressBar = findViewById(R.id.progressBar);
        btnSignup = findViewById(R.id.btn_signup);
        btnLogin = findViewById(R.id.btn_login);
        btnReset = findViewById(R.id.btn_reset_password);


        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, Sign_in.class));
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, ResetPasswordActivity.class));
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emai = inputEmail.getText().toString();
                String email = emai+"@rural.com";
                final String password = inputPassword.getText().toString();

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.enter_email_address), Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.enter_password), Toast.LENGTH_SHORT).show();
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);

                //authenticate user
                auth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                // If sign in fails, display a message to the user. If sign in succeeds
                                // the auth state listener will be notified and logic to handle the
                                // signed in user can be handled in the listener.
                                if (!task.isSuccessful()) {
                                    progressBar.setVisibility(View.GONE);
                                    // there was an error
                                    if (password.length() < 6) {
                                        inputPassword.setError(getString(R.string.minimum_password));
                                    } else {
                                        Toast.makeText(LoginActivity.this, getString(R.string.authentication_failed), Toast.LENGTH_LONG).show();
                                    }
                                } else {
                                    checkAdmin(auth.getCurrentUser().getUid());
                                }
                            }
                        });
            }
        });



    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base));
    }

    private void checkAdmin(String uid) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("/usersAdmin/"+uid);

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                if (dataSnapshot.exists()) {
                    String path = dataSnapshot.getRef().toString();
                    Long value = dataSnapshot.getValue(Long.class);
                    progressBar = findViewById(R.id.progressBar);
                    progressBar.setVisibility(View.GONE);
                    if (value == 1) {
                        Intent intent = new Intent(LoginActivity.this, MapsActivity.class);
                        getApplication().setTheme(R.style.admin);
                        startActivity(intent);
                        finish();

                    } else if (value == 2) {
                        Intent intent = new Intent(LoginActivity.this, AdminBuyerList.class);
                        intent.putExtra("adus", 2);
                        getApplication().setTheme(R.style.buy);
                        startActivity(intent);
                        finish();
                    } else {
                        Intent intent = new Intent(LoginActivity.this, form.class);
                        getApplication().setTheme(R.style.user);
                        startActivity(intent);
                        finish();
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                progressBar = findViewById(R.id.progressBar);
                progressBar.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
}