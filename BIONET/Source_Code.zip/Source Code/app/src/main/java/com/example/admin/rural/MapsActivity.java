package com.example.admin.rural;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.icu.text.Collator;
import android.location.Location;
import android.location.LocationListener;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.maps.android.PolyUtil;
import com.google.maps.android.ui.IconGenerator;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class MapsActivity extends MenuActivity
        implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener {
    private static Polyline line;
    private FirebaseAuth auth2;
    GoogleMap mGoogleMap;
    SupportMapFragment mapFrag;
    LocationRequest mLocationRequest;
    GoogleApiClient mGoogleApiClient;
    LocationCallback mLocationCallback;
    Location mLastLocation;
    Marker mCurrLocationMarker;
    private fb post;
    public int[][] latlong;
    private Collator MySingleton;
    private JSONObject[] js2;
    public static int max;
    private Marker ma;
    private int i;
    Button del;
    private static ArrayList<Marker> arm;
    private FusedLocationProviderClient mFusedLocationClient;
    public Button chg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.admin);
        super.onCreate(savedInstanceState);

        getLayoutInflater().inflate(R.layout.activity_maps, frameLayout);
        if(adus==1){
            ImageButton phone=findViewById(R.id.menu_call_button);
            phone.setVisibility(View.GONE);
            setTheme(R.style.admin);
        }
        setTitle(R.string.map);
        mapFrag = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        mapFrag.getMapAsync(this);
        del =findViewById(R.id.del);
        chg =findViewById(R.id.chg);
        chg.setOnClickListener(new View.OnClickListener() {
                                   @Override
                                   public void onClick(View v) {
                                       chgmap();
                                   }
                               });
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if (arm.isEmpty()){
                   new AlertDialog.Builder(MapsActivity.this)
                           .setTitle(R.string.nolcsl)
                           .setMessage(R.string.tplc)
                           .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                               @Override
                               public void onClick(DialogInterface dialogInterface, int i) {
                               }
                           })
                           .create()
                           .show();
                }
                else{
                   new AlertDialog.Builder(MapsActivity.this)
                           .setTitle(R.string.rus)
                           .setMessage(R.string.oksb)
                           .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                               @Override
                               public void onClick(DialogInterface dialogInterface, int i) {

                                   for (final Marker ar : arm) {
                                       final FirebaseDatabase database = FirebaseDatabase.getInstance();
                                       final DatabaseReference myRef = database.getReference("/data/");
                                       Query q=myRef.orderByChild("lat").equalTo(String.valueOf(ar.getPosition().latitude)); //.orderByChild("long").equalTo(String.valueOf(ar.getPosition().longitude));
                                       q.addValueEventListener(new ValueEventListener() {
                                           @Override
                                           public void onDataChange(DataSnapshot snapshot) {
                                               //go through each item found and print out the emails
                                               //Query q2=myRef.orderByChild("long").equalTo(ar.getPosition().longitude);
                                               if (snapshot.exists()) {
                                               for (DataSnapshot ch:snapshot.getChildren()) {
                                                   final String ke=ch.getRef().getKey();
                                                   Query q2=myRef.orderByChild("long").equalTo(String.valueOf(ar.getPosition().longitude));
                                                   q2.addValueEventListener(new ValueEventListener() {
                                                       @Override
                                                       public void onDataChange(DataSnapshot snapshot) {
                                                           //go through each item found and print out the emails
                                                           //Query q2=myRef.orderByChild("long").equalTo(ar.getPosition().longitude);
                                                           if (snapshot.exists()) {
                                                           for (DataSnapshot ch:snapshot.getChildren()) {
                                                               String ke2=ch.getRef().getKey();
                                                               if(ke==ke2){
                                                                   long time = System.currentTimeMillis();
                                                                   final DatabaseReference myRef2 = database.getReference("/dataLog/"+time);
                                                                   myRef2.setValue(ch.getValue());
                                                                   ch.getRef().removeValue();
                                                               }

                                                           }
                                                       }}

                                                       @Override
                                                       public void onCancelled(@NonNull DatabaseError databaseError) {

                                                       }
                                                   });
                                               }}
                                           }

                                           @Override
                                           public void onCancelled(@NonNull DatabaseError databaseError) {

                                           }
                                       });

                                   }
                               }
                           })
                           .create()
                           .show();

               }
            }
        });
        mLocationCallback = new LocationCallback(){
            @Override
            public void onLocationResult(LocationResult locationResult) {
                for (Location location : locationResult.getLocations()) {

                }
            }

        };
    }

    private void chgmap() {
     if(mGoogleMap.getMapType()==GoogleMap.MAP_TYPE_HYBRID){
         mGoogleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
     }
     else{
         mGoogleMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
     }
    }

    @Override
    public void onPause() {
        super.onPause();

        //stop location updates when Activity is no longer active
        if (mGoogleApiClient != null) {
           LocationServices.getFusedLocationProviderClient(this)
                    .removeLocationUpdates(mLocationCallback);

        }
    }




    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;
        mGoogleMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);

        //Initialize Google Play Services
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                //Location Permission already granted
                buildGoogleApiClient();
                mGoogleMap.setMyLocationEnabled(true);
            } else {
                //Request Location Permission
                checkLocationPermission();
            }
        } else {
            buildGoogleApiClient();
            mGoogleMap.setMyLocationEnabled(true);
        }
    }

    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnected(Bundle bundle) {
        //   mLocationRequest = new LocationRequest();
        //   mLocationRequest.setInterval(1000);
        //   mLocationRequest.setFastestInterval(1000);
        //   mLocationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
        checkLocationPermission();
        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (mLastLocation != null) {
            final double lng = mLastLocation.getLongitude();
            final double lat = mLastLocation.getLatitude();

            if (mCurrLocationMarker != null) {
                mCurrLocationMarker.remove();
            }
            LatLng ll = new LatLng(lat, lng);
            auth2 = FirebaseAuth.getInstance();
            String ui = auth2.getCurrentUser().getEmail();
            String uid=ui.replace("@rural.com", "");
            latlong = new int[10][10];
            //js2 = direction(latlong);
            //Log.e("ddd", String.valueOf(js2.length));
            final MarkerOptions markerOpt = new MarkerOptions().title(getString(R.string.mlc)).snippet(uid)
                    .position(ll)
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
            //CustomInfoWindowGoogleMap customInfoWindow = new CustomInfoWindowGoogleMap(this);
            //mGoogleMap.setInfoWindowAdapter(customInfoWindow);

            mCurrLocationMarker = mGoogleMap.addMarker(markerOpt);
            mCurrLocationMarker.showInfoWindow();
            mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(ll, 15));
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("/data/");

            myRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    // This method is called once with the initial value and again
                    // whenever data at this location is updated.
                    if (snapshot.exists()) {
                    mGoogleMap.clear();
                    mCurrLocationMarker = mGoogleMap.addMarker(markerOpt);
                    mCurrLocationMarker.showInfoWindow();
                    collectdata((Map<String, Object>) snapshot.getValue());

                }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }

    private void collectdata(Map<String, Object> users) {
        arm=new ArrayList<Marker>();
        ArrayList<String> email = new ArrayList<>();
        ArrayList<String> unit = new ArrayList<>();
        ArrayList<String> lat = new ArrayList<>();
        ArrayList<String> lon = new ArrayList<>();
        ArrayList<String> amt = new ArrayList<>();
        ArrayList<String> name = new ArrayList<>();
        RetItem rel = new RetItem();
        //iterate through each user, ignoring their UID
        for (Map.Entry<String, Object> entry : users.entrySet()) {
            String s = new String();
            //Get user map
            Map singleUser = (Map) entry.getValue();
            Map<String, Object> kk = (Map<String, Object>) entry.getValue();

            //Get phone field and append to list

            for (Map.Entry<String, Object> entry2 : kk.entrySet()) {
                if (entry2.getValue() instanceof ArrayList) {
                    ArrayList kk2 = (ArrayList) entry2.getValue();
                    for (Object entry3 : kk2) {
                        //       amt.add((String) entry3.getValue().get("amt"));
                        //        name.add((String) entry3.get("name"));
                        s = s + "\n" + entry3.toString();

                    }

                }
                // rel= (RetItem) singleUser2.entrySet();
            }
            email.add((String) singleUser.get("email"));
            //unit.add((String) singleUser.get("unit"));
            lat.add((String) singleUser.get("lat"));
            lon.add((String) singleUser.get("long"));
            LatLng ll2 = new LatLng(Double.parseDouble(Objects.requireNonNull(singleUser.get("lat")).toString()), Double.parseDouble(Objects.requireNonNull(singleUser.get("long")).toString()));
            IconGenerator iconGenerator = new IconGenerator(this);
            iconGenerator.setStyle(IconGenerator.STYLE_WHITE);

            Bitmap iconBitmap = iconGenerator.makeIcon(getString(R.string.usrlcl)+"\n" + singleUser.get("email") + s.replace("name=", "").replace("amt=", ""));
            mGoogleMap.addMarker(new MarkerOptions().title("User Location").icon(BitmapDescriptorFactory.fromBitmap(iconBitmap)).position(ll2)).setTag(0) ;


        }
        mGoogleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener(){

            @Override
            public boolean onMarkerClick(Marker marker) {
                String s=getString(R.string.mlc);

                if(!marker.getTitle().equalsIgnoreCase(s)) {
                    if(0 == Integer.parseInt(String.valueOf(marker.getTag()))) {
                        if (line != null) {
                            line.remove();
                        }
                        marker.setAlpha((float) 0.5);
                        marker.setTag(1);
                        arm.add(marker);
                        optimize((ArrayList<Marker>) arm.clone());
                        //direction(ma);

                    }
                    else if(1 == Integer.parseInt(String.valueOf(marker.getTag()))) {
                        if(line!=null){
                            line.remove();}
                        marker.setAlpha((float) 1);
                        marker.setTag(0);
                        arm.remove(marker);
                        optimize((ArrayList<Marker>) arm.clone());
                        //direction(ma);


                    }
                }
                return false;
            }
        });
    }

    private void optimize(ArrayList<Marker> ar) {
        MapsActivity.max=0;
        i=0;
        for (final Marker mx:ar){
            String url = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=" + String.valueOf(mLastLocation.getLatitude()) + "," + String.valueOf(mLastLocation.getLongitude()) + "&destinations="+String.valueOf(mx.getPosition().latitude)+","+String.valueOf(mx.getPosition().longitude)+"&mode=WALKING&key=AIzaSyAk0BckFt-zRtXwI9xIwwqitRIGtsh_BoQ";
            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                    (Request.Method.POST, url, null, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            JSONObject k = null;
                            try {
                                k = (JSONObject) response.getJSONArray("rows").get(0);
                                String m = null;
                                try {
                                    m = k.getJSONArray("elements").getJSONObject(0).getJSONObject("distance").getString("value");
                                    if(Integer.parseInt(m)>max){
                                        max=Integer.parseInt(m);
                                        ma=mx;
                                    }
                                    if (i==arm.size()-1){
                                        setmax(max,ma);}
                                    i=i+1;
                                } catch (JSONException e) {
                                }
                            } catch (JSONException e) {
                            }
                        }
                    }, new Response.ErrorListener() {

                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // TODO: Handle error
                        }
                    });
            requestQueue.add(jsonObjectRequest);
        }

    }

    private void setmax(int max, Marker ma) {
        MapsActivity.max=0;
        MapsActivity.max =max;
        ArrayList<Marker> ari = (ArrayList<Marker>) MapsActivity.arm.clone();
        ari.remove(ma);
        direction(ma,ari);

    }


    @Override
    public void onConnectionSuspended(int i) {
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
    }

    @Override
    public void onLocationChanged(Location location) {
        mLastLocation = location;
        if (mCurrLocationMarker != null) {
            mCurrLocationMarker.remove();
        }

        //Place current location marker
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title(getString(R.string.crntpos));
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA));
        mCurrLocationMarker = mGoogleMap.addMarker(markerOptions);

        //move map camera
        mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle(R.string.lclprm)
                        .setMessage(R.string.lclprmtxt)
                        .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(MapsActivity.this,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        if (mGoogleApiClient == null) {
                            buildGoogleApiClient();
                        }
                        mGoogleMap.setMyLocationEnabled(true);
                    }

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(this, R.string.prmden, Toast.LENGTH_LONG).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    private JSONObject[] direction(Marker marker, ArrayList<Marker> ari) {
        if(MapsActivity.line!=null){
        MapsActivity.line.remove();
        }
        String url=null;
        if (ari.size()!=0) {
            String via="";
            for (Marker mai : ari) {
                via = via + "|" + String.valueOf(mai.getPosition().latitude) +","+String.valueOf(mai.getPosition().longitude);
            }
            url = "https://maps.googleapis.com/maps/api/directions/json?origin=" + String.valueOf(mLastLocation.getLatitude()) + "," + String.valueOf(mLastLocation.getLongitude()) + "&destination=" + String.valueOf(marker.getPosition().latitude) + "," + String.valueOf(marker.getPosition().longitude) + "&waypoints=optimize:true" + via + "&mode=WALKING&key=AIzaSyAk0BckFt-zRtXwI9xIwwqitRIGtsh_BoQ";
            }
        else if(ari.size()==0){
            url = "https://maps.googleapis.com/maps/api/directions/json?origin=" + String.valueOf(mLastLocation.getLatitude()) + "," + String.valueOf(mLastLocation.getLongitude()) + "&destination=" + String.valueOf(marker.getPosition().latitude) + "," + String.valueOf(marker.getPosition().longitude) + "&mode=WALKING&key=AIzaSyAk0BckFt-zRtXwI9xIwwqitRIGtsh_BoQ";
        }

        final JSONObject[] js = {new JSONObject()};
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {

                        JSONObject k = null;
                        try {
                            k = (JSONObject) response.getJSONArray("routes").get(0);
                            String m = null;
                            try {
                                m = k.getJSONObject("overview_polyline").getString("points");

                                List<LatLng> list = PolyUtil.decode(m);

                                PolylineOptions options = new PolylineOptions().width(10).color(Color.BLUE).addAll(list).visible(true).zIndex(30);
                                 MapsActivity.line = mGoogleMap.addPolyline(options);


                            } catch (JSONException e) {

                            }
                        } catch (JSONException e) {

                        }


                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO: Handle error


                    }
                });
        requestQueue.add(jsonObjectRequest);

// Access the RequestQueue through your singleton class.
        return js;
    }
}