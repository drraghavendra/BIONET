package com.example.admin.rural;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.ImageButton;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MenuActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private FirebaseAuth.AuthStateListener authListener;
    private FirebaseAuth auth;
    FrameLayout frameLayout;
    Toolbar toolbar;
    DrawerLayout drawer;
    NavigationView navigationView;
    NavigationView navigationView3;
    NavigationView navigationView2;
    public int adus;
    private ImageButton callButton;
    public static final int MY_PERMISSIONS_REQUEST_CALL = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        //get firebase auth instance
        auth = FirebaseAuth.getInstance();
        authListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user == null) {
                    // user auth state is changed - user is null
                    // launch login activity
                    startActivity(new Intent(MenuActivity.this, LoginActivity.class));
                    finish();
                }
            }
        };
        super.onCreate(savedInstanceState);
        LocaleHelper.setLocale(getApplicationContext(), LocaleHelper.getLanguage(getApplicationContext()));
        setContentView(R.layout.menu);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        frameLayout = findViewById(R.id.content_frame);
        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        //get current user
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        final String uid = user.getUid();
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("/usersAdmin/" + uid);

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                if (dataSnapshot.exists()) {
                String path = dataSnapshot.getRef().toString();
                Long value = dataSnapshot.getValue(Long.class);
                if (value == 1) {
                    navigationView2 = findViewById(R.id.nav_view);
                    navigationView2.setVisibility(View.VISIBLE);
                    adus = 1;
                    callButton = findViewById(R.id.menu_call_button);
                    if(adus==1){
                        callButton.setVisibility(View.GONE);
                    }
                    else{
                        callButton.setVisibility(View.VISIBLE);
                        callButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                try {
                                    Intent callIntent = new Intent(Intent.ACTION_DIAL);
                                    callIntent.setData(Uri.parse("tel:"+getString(R.string.contact_number)));
                                    startActivity(callIntent);
                                }catch (Exception e){

                                }
                            }
                        });
                    }
                } else if (value == 2) {
                    navigationView2 = findViewById(R.id.nav_view3);
                    navigationView2.setVisibility(View.VISIBLE);
                    adus = 2;

                } else {
                    adus = 0;
                    navigationView2 = findViewById(R.id.nav_view2);
                    navigationView2.setVisibility(View.VISIBLE);

                }}
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }
        });

        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView2 = findViewById(R.id.nav_view2);
        navigationView2.setNavigationItemSelectedListener(this);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView3 = findViewById(R.id.nav_view3);
        navigationView3.setNavigationItemSelectedListener(this);



    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base));
    }



    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_manage) {
            navigationView.setCheckedItem(id);
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("adus", adus);
            startActivity(intent);
            finish();
        }
        else if (id == R.id.nav_map) {
            navigationView.setCheckedItem(id);
            Intent intent = new Intent(this, MapsActivity.class);
            startActivity(intent);
            finish();

        }else if (id == R.id.nav_adusl) {
            navigationView.setCheckedItem(id);
            Intent intent = new Intent(this, AdminUserList.class);
            startActivity(intent);
            finish();

        }
        else if (id == R.id.nav_adbyl) {
            navigationView.setCheckedItem(id);
            Intent intent = new Intent(this, AdminBuyerList.class);
            startActivity(intent);
            finish();

        }
        else if (id == R.id.nav_adbyllog) {
            navigationView.setCheckedItem(id);
            Intent intent = new Intent(this, AdminBuyerListLog.class);
            startActivity(intent);
            finish();

        }else if (id == R.id.nav_buylog) {
            navigationView.setCheckedItem(id);
            Intent intent = new Intent(this, AdminBuyerListLog.class);
            intent.putExtra("adus", adus);
            startActivity(intent);
            finish();

        }else if (id == R.id.nav_form) {
            navigationView.setCheckedItem(id);
            Intent intent = new Intent(this, form.class);
            startActivity(intent);
            finish();
        }else if (id == R.id.nav_buy) {
                navigationView.setCheckedItem(id);
                Intent intent = new Intent(this, AdminBuyerList.class);
                intent.putExtra("adus", adus);
                startActivity(intent);

                finish();
        }
        else if (id == R.id.nav_addcrop) {
            navigationView.setCheckedItem(id);
            Intent intent = new Intent(this, AdminUserPriceList.class);
            intent.putExtra("adus", adus);
            startActivity(intent);
            finish();
        }
        else if (id == R.id.nav_adusllog) {
            navigationView.setCheckedItem(id);
            Intent intent = new Intent(this, AdminSellerLog.class);
            intent.putExtra("adus", adus);
            startActivity(intent);
            finish();
        }
        else if (id == R.id.nav_usllog) {
            navigationView.setCheckedItem(id);
            Intent intent = new Intent(this, AdminSellerLog.class);
            intent.putExtra("adus", adus);
            startActivity(intent);
            finish();
        }
        else if (id == R.id.nav_mrkt) {
            navigationView.setCheckedItem(id);
            Intent intent = new Intent(this, AdminUserPriceList.class);
            intent.putExtra("adus", adus);
            startActivity(intent);
            finish();
        }else if (id == R.id.nav_out) {
            navigationView.setCheckedItem(id);
            auth.signOut();
            final Intent intent = new Intent(this, LoginActivity.class);
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    startActivity(intent);
                    finish();
                }
            }, 2000);   //5 seconds

        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
