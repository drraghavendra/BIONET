package com.example.admin.rural;

public class RetItem
{
    public String name;
    public int amt;
}
