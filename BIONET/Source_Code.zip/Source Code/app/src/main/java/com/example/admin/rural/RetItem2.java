package com.example.admin.rural;

public class RetItem2
{
    public String name;
    public int tamt;
    public int tprice;
}
