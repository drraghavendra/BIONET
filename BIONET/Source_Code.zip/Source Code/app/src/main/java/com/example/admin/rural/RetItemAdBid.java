package com.example.admin.rural;

public class RetItemAdBid
{
    public String name;
    public int amtmin;
    public int amtmax;
    public int tprice;
}
