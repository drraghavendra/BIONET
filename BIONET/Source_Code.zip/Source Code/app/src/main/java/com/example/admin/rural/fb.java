package com.example.admin.rural;

public class fb extends RetItem{
    public String emai;
    public String lat;
    public String lon;


}
