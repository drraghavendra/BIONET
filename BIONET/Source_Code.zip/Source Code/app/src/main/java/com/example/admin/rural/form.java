package com.example.admin.rural;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.google.android.gms.location.LocationServices;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class form extends MenuActivity implements LocationListener {
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private static RecyclerView mPatientRecyclerView;
    private FirebaseAuth auth2;
    private LocationManager locationManager;
    private Location mLastLocation;
    public String k;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.user);
        getLayoutInflater().inflate(R.layout.activity_form, frameLayout);
        setTitle(R.string.add_amount);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        checkLocationPermission();
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 100, this);
        mPatientRecyclerView = this.findViewById(R.id.patientRecyclerView);
        mPatientRecyclerView.setHasFixedSize(true);
        k=LocaleHelper.getLanguage(this);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mPatientRecyclerView.setLayoutManager(linearLayoutManager);
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("/biddingMax/");
        final Spinner spin2= this.findViewById(R.id.spinner);

            myRef.orderByKey().addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        int i=0;
                        Map<String, Object> mItems= (Map<String, Object>) snapshot.getValue();
                        List<String> list = new ArrayList<String>();
                        for (Map.Entry<String, Object> entry : mItems.entrySet()) {
                            String s = new String();
                            //   Map singleUser = (Map) entry.getValue();
                            //   Map<String, Object> kk = (Map<String, Object>) entry.getValue();
                            i=i+1;
                            list.add(String.valueOf(i));

                        }
                        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, list);
                        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spin2.setAdapter(spinnerAdapter);


                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });



        spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int
                    i, long id) {
                // On selecting a spinner item
               updateAdapter(parent.getSelectedItem().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // todo for nothing selected
            }
        });
             //   addListenerOnSpinnerItemSelection();

    }

    public void updateAdapter(String num) {

        Adapter2 adapter = new Adapter2(this,num);
        adapter.notifyDataSetChanged();
        mPatientRecyclerView.setAdapter(adapter);
    }

    public void addListenerOnSpinnerItemSelection() {
        Spinner spinner1 = findViewById(R.id.spinner);
        spinner1.setOnItemSelectedListener(new CustomOnItemSelectedListener());

    }

    public void onClickBtnfr(View view) {
        final List<RetItem> rel =Adapter2.retrieveData();
        checkLocationPermission();
        mLastLocation =locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
        auth2 = FirebaseAuth.getInstance();
        Long currentTime = Calendar.getInstance().getTimeInMillis();
        String uid=auth2.getCurrentUser().getUid();
        String emai=auth2.getCurrentUser().getEmail();
        final String email=emai.replace("@rural.com", "");
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("/data/");
        final DatabaseReference newRef = myRef.child(uid).child("latest");
        final DatabaseReference newRf = myRef.child(uid).child("email");
        final DatabaseReference lat = myRef.child(uid).child("lat");
        final DatabaseReference lon = myRef.child(uid).child("long");
        DatabaseReference myRef2 = database.getReference("/biddingMax/");
        myRef2.orderByKey().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Map<String, Object> mItems= (Map<String, Object>) snapshot.getValue();
                    List<String> list = new ArrayList<String>();
                    List<String> listp = new ArrayList<String>();
                    for (Map.Entry<String, Object> entry : mItems.entrySet()) {
                        String s = new String();
                        //   Map singleUser = (Map) entry.getValue();
                        //   Map<String, Object> kk = (Map<String, Object>) entry.getValue();

                        list.add((String) entry.getKey());
                        listp.add((String) entry.getValue());

                    }

                    String[] prices=getResources().getStringArray(R.array.prices);
                    int i=0;
                    float sum=0;
                    String su="";
                    for( RetItem re:rel) {
                        for(String na:list){
                            String ll=re.name;
                            String l= chktran2(ll);
                            String na2=chktran(ll);
                            if(l.equals(na)){
                                sum=sum+Float.parseFloat(listp.get(i))*re.amt;
                                su=su + na2+" "+getString(R.string.rs_kg) +" "+ listp.get(i) + " * " + re.amt+" "+getString(R.string.kg_eq_rs)+" "+Float.parseFloat(listp.get(i))*re.amt+"\n";
                            }
                            i=i+1;
                        }
                        i=0;
                    }
                    su=su.replace("=+","");
                    new AlertDialog.Builder(getContext())
                            .setTitle(R.string.oksb)
                            .setMessage(su+getString(R.string.cshpd)+" "+sum)
                            .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    lat.setValue(String.valueOf(mLastLocation.getLatitude()));
                                    lon.setValue(String.valueOf(mLastLocation.getLongitude()));
                                    //Prompt the user once explanation has been shown
                                    newRf.setValue(email);
                                    newRef.setValue(rel);
                                    recreate();

                                }
                            })
                            .create()
                            .show();


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    private String chktran2(String dt) {
        String dt2;
        dt2=dt.replace("बाजरा","Bajra").replace("चना","Gram").replace("ज्वार","Jawar").replace("मसूर","Lentil").replace("मक्का","Maize").replace("सरसों","Mustard").replace("सोयाबीन","Soya bean").replace("गन्ना","Sugarcane").replace("गेहूँ","Wheat").replace("मूंगफली","Groundnut").replace("चावल","Rice").replace("बाजरी","Bajra").replace("ग्राम","Gram").replace("जवार","Jawar").replace("दालचिनी","Lentil").replace("मका","Maize").replace("मोहरी","Mustard").replace("सोयाबीन","Soya bean").replace("ऊस","Sugarcane").replace("गहू","Wheat").replace("भुईमूग","Groundnut").replace("तांदूळ","Rice");

        return dt2;
    }
    private String chktran(String dt) {
        String dt2=dt;
        Log.e("Lang",k);
        if(k.equals("hi")){
            if(dt.contains("Bajra")){
                dt2=dt.replace("Bajra","बाजरा");
            }
            else if(dt.contains("Gram")){
                dt2=dt.replace("Gram","चना");
            }
            else if(dt.contains("Jawar")){
                dt2=dt.replace("Jawar","ज्वार");
            }
            else if(dt.contains("Lentil")){
                dt2=dt.replace("Lentil","मसूर");
            }
            else if(dt.contains("Maize")){
                dt2=dt.replace("Maize","मक्का");
            }
            else if(dt.contains("Mustard")){
                dt2=dt.replace("Mustard","सरसों");
            }
            else if(dt.contains("Soya bean")){
                dt2=dt.replace("Soya bean","सोयाबीन");
            }
            else if(dt.contains("Sugarcane")){
                dt2=dt.replace("Sugarcane","गन्ना");
            }
            else if(dt.contains("Wheat")){
                dt2=dt.replace("Wheat","गेहूँ");
            }
            else if(dt.contains("Groundnut")){
                dt2=dt.replace("Groundnut","मूंगफली");
            }
            else if(dt.contains("Rice")){
                dt2=dt.replace("Rice","चावल");
            }
        }
        else if(k.equals("mr")){
            if(dt.contains("Bajra")){
                dt2=dt.replace("Bajra","बाजरी");
            }
            else if(dt.contains("Gram")){
                dt2=dt.replace("Gram","ग्राम");
            }
            else if(dt.contains("Jawar")){
                dt2=dt.replace("Jawar","जवार");
            }
            else if(dt.contains("Lentil")){
                dt2=dt.replace("Lentil","दालचिनी");
            }
            else if(dt.contains("Maize")){
                dt2=dt.replace("Maize","मका");
            }
            else if(dt.contains("Mustard")){
                dt2=dt.replace("Mustard","मोहरी");
            }
            else if(dt.contains("Soya bean")){
                dt2=dt.replace("Soya bean","सोयाबीन");
            }
            else if(dt.contains("Sugarcane")){
                dt2=dt.replace("Sugarcane","ऊस");
            }
            else if(dt.contains("Wheat")){
                dt2=dt.replace("Wheat","गहू");
            }
            else if(dt.contains("Groundnut")){
                dt2=dt.replace("Groundnut","भुईमूग");
            }
            else if(dt.contains("Rice")){
                dt2=dt.replace("Rice","तांदूळ");
            }
        }
        else if(k.equals("en")){
            dt2= dt;
        }
        return dt2;
    }

    private Context getContext() {
        return this;
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle(R.string.lclprm)
                        .setMessage(R.string.lclprmtxt)
                        .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(form.this,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION );
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION );
            }
        }
    }

    @Override
    public void onLocationChanged(Location location) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
