package com.example.admin.rural;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class formBid extends AppCompatActivity{
    public String mini="";
    public String rskg="";
    public String spi="";
    public String address="";
    Toolbar toolbar;
public int adus;
    protected void onCreate(Bundle savedInstanceState) {
        adus = getIntent().getIntExtra("adus", 1);
        setTheme(R.style.admin);
        super.onCreate(savedInstanceState);
    //    getLayoutInflater().inflate(R.layout.activity_bidform, frameLayout);
        setTitle(R.string.add_to_bidding_list);
        LocaleHelper.setLocale(getApplicationContext(),LocaleHelper.getLanguage(getApplicationContext()));
        setContentView(R.layout.activity_bidform);

        // toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar2);
        setSupportActionBar(toolbar);

        // add back arrow to toolbar
        if (getSupportActionBar() != null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        final Button butn=this.findViewById(R.id.butn);
        butn.setActivated(false);
        butn.setAlpha((float) 0.1);
        butn.setText(R.string.cmpltfrm);
        final Spinner spin= this.findViewById(R.id.spin1);
        newlist(spin);
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int
                    i, long id) {
                // On selecting a spinner item
                spi = parent.getSelectedItem().toString();
                chekbtn(butn);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // todo for nothing selected
            }
        });
        final Spinner spin2= this.findViewById(R.id.spin22);
        spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int
                    i, long id) {
                // On selecting a spinner item
                mini = parent.getSelectedItem().toString();
                chekbtn(butn);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // todo for nothing selected
            }
        });
        final EditText amt3 = this.findViewById(R.id.amt3);
        amt3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                rskg=charSequence.toString();
                chekbtn(butn);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        final EditText amt4 = this.findViewById(R.id.amt4);
        amt4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                address=charSequence.toString();
                chekbtn(butn);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        butn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chekbtn(butn);
                if (butn.isActivated()) {
                    new AlertDialog.Builder(formBid.this)
                            .setTitle(R.string.rus)
                            .setMessage(getString(R.string.oksbn)+"\n"+getString(R.string.crcst)+ Float.parseFloat(rskg)*Float.parseFloat(mini)*1000)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                                    DatabaseReference myRef = database.getReference("/bidFormData");
                                    long time = System.currentTimeMillis();
                                    DatabaseReference newRef = myRef.child(Long.toString(time)).child("name");
                                    DatabaseReference newRf = myRef.child(Long.toString(time)).child("amtmin");
                                    DatabaseReference lon = myRef.child(Long.toString(time)).child("rskg");
                                    DatabaseReference lon2 = myRef.child(Long.toString(time)).child("minrskg");
                                    DatabaseReference li = myRef.child(Long.toString(time)).child("bidmaxuser");
                                    DatabaseReference add = myRef.child(Long.toString(time)).child("address");
                                    newRef.setValue(spi);
                                    newRf.setValue(mini);
                                    add.setValue(address);
                                    lon.setValue(rskg);
                                    lon2.setValue(rskg);
                                    li.setValue("None");
                                    amt3.setText(null);
                                    amt4.setText(null);
                                    Intent intent = new Intent(formBid.this, AdminBuyerList.class);
                                    intent.putExtra("adus",adus);
                                    getApplication().setTheme(R.style.admin);
                                    startActivity(intent);
                                    finish();
                                }
                            })
                            .create()
                            .show();
                }
            }
        });
    }

    private void newlist(final Spinner spin) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("/biddingMax/");
        myRef.orderByKey().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Map<String, Object> mItems= (Map<String, Object>) snapshot.getValue();
                    List<String> list = new ArrayList<String>();
                    for (Map.Entry<String, Object> entry : mItems.entrySet()) {
                        String s = new String();
                        //   Map singleUser = (Map) entry.getValue();
                        //   Map<String, Object> kk = (Map<String, Object>) entry.getValue();

                        list.add((String) entry.getKey());

                    }
                    ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, list);
                    spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin.setAdapter(spinnerAdapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private Context getContext() {
       return this;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // handle arrow click here
        if (item.getItemId() == android.R.id.home) {
            Intent intent = new Intent(this, AdminBuyerList.class);
            startActivity(intent);
            finish(); // close this activity and return to preview activity (if there is any)
        }

        return super.onOptionsItemSelected(item);
    }
    private void chekbtn(Button butn) {
        if(!mini.equals("") && !rskg.equals("")&& !spi.equals("")&& !address.equals("")){
                butn.setActivated(true);
                butn.setAlpha(1);
                butn.setText(R.string.submit);

        }
        else{
            butn.setActivated(false);
            butn.setAlpha((float) 0.1);
            butn.setText(R.string.cmpltfrm);
        }
    }
}
