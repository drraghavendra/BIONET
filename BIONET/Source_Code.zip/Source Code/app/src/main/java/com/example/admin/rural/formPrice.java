package com.example.admin.rural;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class formPrice extends AppCompatActivity{
    public String mini="";
    public String rskg="";
    public String rskgold="";
    public String spi="";
    public String address="";
    Toolbar toolbar;
    public int adus;
    public String dt;
    public String dt2;

    protected void onCreate(Bundle savedInstanceState) {
        adus = getIntent().getIntExtra("adus", 1);
        if (adus == 1) {
            setTheme(R.style.admin);
            setTitle(R.string.adprs);
        } else if (adus == 0) {
            setTheme(R.style.admin);
            setTitle(R.string.edprs);
            dt = getIntent().getStringExtra("dt");
            dt2 = getIntent().getStringExtra("dt2");
        }
        super.onCreate(savedInstanceState);
    //    getLayoutInflater().inflate(R.layout.activity_bidform, frameLayout);
    //    setTitle(R.string.add_to_bidding_list);
        LocaleHelper.setLocale(getApplicationContext(),LocaleHelper.getLanguage(getApplicationContext()));
        setContentView(R.layout.activity_priceform);

        // toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar2);
        setSupportActionBar(toolbar);

        // add back arrow to toolbar
        if (getSupportActionBar() != null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        final Button butn=this.findViewById(R.id.butn);
        butn.setActivated(false);
        butn.setAlpha((float) 0.1);
        butn.setText(R.string.cmpltfrm);
        final EditText amt3 = this.findViewById(R.id.amt3);
        if (adus==0){
            amt3.setText(dt);
            rskgold=dt;
            rskg=dt;
        }
        amt3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                rskg=charSequence.toString();
                chekbtn(butn);
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        final EditText amt4 = this.findViewById(R.id.amt4);
        if (adus==0){
            amt4.setText(dt2);
            address=dt2;
           }

        amt4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                address=charSequence.toString();
                chekbtn(butn);
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        butn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chekbtn(butn);
                if (butn.isActivated()) {
                    new AlertDialog.Builder(formPrice.this)
                            .setTitle(R.string.rus)
                            .setMessage(R.string.oksb)
                            .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                                    if (adus==0){
                                        DatabaseReference myRef2 = database.getReference("/biddingMax/"+rskgold);
                                        myRef2.getRef().removeValue();

                                    }
                                    DatabaseReference myRef = database.getReference("/biddingMax/"+rskg);
                                    myRef.setValue(address);
                                    amt3.setText(null);
                                    amt4.setText(null);
                                    Intent intent = new Intent(formPrice.this, AdminUserPriceList.class);
                                    intent.putExtra("adus", 1);
                                    startActivity(intent);
                                    finish();
                                }
                            })
                            .create()
                            .show();
                }
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // handle arrow click here
        if (item.getItemId() == android.R.id.home) {
            Intent intent = new Intent(this, AdminUserPriceList.class);
            intent.putExtra("adus", adus);
            startActivity(intent);
            finish(); // close this activity and return to preview activity (if there is any)
        }

        return super.onOptionsItemSelected(item);
    }
    private void chekbtn(Button butn) {
        if(!rskg.equals("")&&!address.equals("")){
                butn.setActivated(true);
                butn.setAlpha(1);
                butn.setText(R.string.submit);

        }
        else{
            butn.setActivated(false);
            butn.setAlpha((float) 0.1);
            butn.setText(R.string.cmpltfrm);
        }
    }
}
